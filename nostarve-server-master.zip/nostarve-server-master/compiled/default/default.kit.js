"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefaultKit = void 0;
function getDefaultKit() {
    return [
        ["fire", 1],
        ["berry", 2]
    ];
}
exports.getDefaultKit = getDefaultKit;
