"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorldTime = void 0;
var WorldTime;
(function (WorldTime) {
    WorldTime[WorldTime["DAY"] = 0] = "DAY";
    WorldTime[WorldTime["NIGHT"] = 1] = "NIGHT";
})(WorldTime || (exports.WorldTime = WorldTime = {}));
