"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameMode = void 0;
var GameMode;
(function (GameMode) {
    GameMode[GameMode["normal"] = 0] = "normal";
    GameMode[GameMode["forest"] = 4] = "forest";
    GameMode[GameMode["community"] = 6] = "community";
})(GameMode || (exports.GameMode = GameMode = {}));
