"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BiomeType = void 0;
var BiomeType;
(function (BiomeType) {
    BiomeType["FOREST"] = "FOREST";
    BiomeType["WINTER"] = "WINTER";
    BiomeType["SEA"] = "SEA";
    BiomeType["DESERT"] = "DESERT";
    BiomeType["LAVA"] = "LAVA";
    BiomeType["DRAGON"] = "DRAGON";
})(BiomeType || (exports.BiomeType = BiomeType = {}));
