"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class AI {
    static aggressive(animal) {
    }
    static passive(animal) {
    }
    static default(animal) {
    }
}
exports.default = AI;
