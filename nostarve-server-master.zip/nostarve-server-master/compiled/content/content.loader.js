"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentLoader = void 0;
class ContentLoader {
    server;
    constructor(server) {
        this.server = server;
    }
    load() {
    }
}
exports.ContentLoader = ContentLoader;
