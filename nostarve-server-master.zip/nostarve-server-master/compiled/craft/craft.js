"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Craft {
    r;
    w;
    o;
    f;
    e;
    time;
    bonus;
    constructor() {
        this.r = [];
        this.w = 0;
        this.o = 0;
        this.f = 0;
        this.e = 0;
        this.time = 0;
        this.bonus = 0;
    }
}
exports.default = Craft;
