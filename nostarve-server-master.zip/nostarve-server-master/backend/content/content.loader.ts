import {Server} from "../server";

export class ContentLoader {
    public server: Server;
    constructor(server: Server) {
        this.server = server;
    }

    public load() {

    }
}