export enum GameMode {
    normal,
    forest = 4,
    community = 6
}