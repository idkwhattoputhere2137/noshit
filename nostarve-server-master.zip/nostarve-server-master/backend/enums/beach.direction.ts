export enum BeachDirection {
    TOP = 1,
    BOTTOM = 2,
    LEFT = 4,
    RIGHT = 8
}