export enum ActionType {
    DELETE = 1,
    HURT = 2,
    COLD = 4,
    HUNGER = 8,
    ATTACK = 16,
    HEAL = 32,
    WEB = 64
}