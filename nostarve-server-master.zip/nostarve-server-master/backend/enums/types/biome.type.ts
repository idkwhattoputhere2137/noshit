export enum BiomeType {
    FOREST = "FOREST",
    WINTER = "WINTER",
    SEA = "SEA",
    DESERT = "DESERT",
    LAVA = "LAVA",
    DRAGON = "DRAGON"
}