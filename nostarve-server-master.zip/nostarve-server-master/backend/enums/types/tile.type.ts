export enum TileType {
    RIVER = "r",
    TREE = "t",
    BIG_TREE = "b",
    WINTER_TREE = "f",
    STONE = "s",
    GOLD = "g",
    DIAMOND = "d",
    AMETHYST = "a",
    REIDITE = "re",
    EMERALD = "m",
    BERRY = "p",
    CACTUS = "c",
    LAVA = "la",
    SAND = "iblk"
}