export enum Permissions {
    PLAYER,
    CO_OWNER,
    OWNER
}