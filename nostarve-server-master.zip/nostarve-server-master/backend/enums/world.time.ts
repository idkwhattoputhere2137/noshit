export enum WorldTime {
    DAY,
    NIGHT
}