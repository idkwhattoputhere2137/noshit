export enum MovementDirection {
    UP = 0,
    DOWN = 1,
    LEFT = 2,
    RIGHT = 3
}