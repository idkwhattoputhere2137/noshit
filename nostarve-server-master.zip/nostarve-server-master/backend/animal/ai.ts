import Animal from "./animal";

export default class AI {
    public static aggressive(animal: Animal) {

    }

    public static passive(animal: Animal) {

    }

    public static default(animal: Animal) {

    }
}