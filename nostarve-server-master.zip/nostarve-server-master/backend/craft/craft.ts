export default class Craft {
    public r: [number, number][];
    public w: number;
    public o: number;
    public f: number;
    public e: number;
    public time: number;
    public bonus: number;
    constructor() {
        this.r = [];
        this.w = 0;
        this.o = 0;
        this.f = 0;
        this.e = 0;
        this.time = 0;
        this.bonus = 0;
    }
}