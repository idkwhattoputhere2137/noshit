export function getDefaultKit(): any {
    return [
        ["fire", 1],
        ["berry", 2]
    ];
}